Esta web muestra el Business Canvas Model de TalentBridge, un proyecto de la asignatura IPE II de Valentina Noreña,
Cristina Pacheco y Asier de Blas de 2ºDAW en el instituto IES Arcipreste de Hita.

Para visualizarla correctamente:

1. Descomprime el fichero para que todos los archivos internos se carguen bien y se pueda visualizar correctamente.

2. No cambies las rutas internas de ningún archivo, o surgirán problemas.

3. Abre el archivo "index.html" haciendo doble clic o usando tu navegador de confianza.

Así podrás ver el proyecto completo en tu ordenador.
